"use client"

import useSWR from "swr"
import type { Project, ApiResponse } from "@/lib/types"
import { API_ENDPOINTS } from "@/lib/constants"

const fetcher = async (url: string) => {
  const response = await fetch(url, { credentials: "include" })
  if (!response.ok) {
    throw new Error("Failed to fetch")
  }
  const data: ApiResponse<Project[]> = await response.json()
  return data.data || []
}

export function useProjects() {
  const { data, error, isLoading, mutate } = useSWR<Project[]>(API_ENDPOINTS.PROJECTS.LIST, fetcher)

  const createProject = async (projectData: { name: string; description?: string }) => {
    const response = await fetch(API_ENDPOINTS.PROJECTS.CREATE, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(projectData),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Failed to create project")
    }

    mutate() // Refresh the projects list
    return response.json()
  }

  return {
    projects: data || [],
    loading: isLoading,
    error,
    createProject,
    refresh: mutate,
  }
}

export function useProject(projectId: string) {
  const { data, error, isLoading, mutate } = useSWR<Project>(
    projectId ? API_ENDPOINTS.PROJECTS.DETAIL(projectId) : null,
    fetcher,
  )

  const updateProject = async (updates: Partial<Project>) => {
    const response = await fetch(API_ENDPOINTS.PROJECTS.UPDATE(projectId), {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(updates),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Failed to update project")
    }

    mutate()
    return response.json()
  }

  return {
    project: data,
    loading: isLoading,
    error,
    updateProject,
    refresh: mutate,
  }
}
