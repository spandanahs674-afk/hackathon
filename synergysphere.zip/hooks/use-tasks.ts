"use client"

import useSWR from "swr"
import type { Task, ApiResponse, TaskFilters } from "@/lib/types"
import { API_ENDPOINTS } from "@/lib/constants"

const fetcher = async (url: string) => {
  const response = await fetch(url, { credentials: "include" })
  if (!response.ok) {
    throw new Error("Failed to fetch")
  }
  const data: ApiResponse<Task[]> = await response.json()
  return data.data || []
}

export function useTasks(projectId: string, filters?: TaskFilters) {
  const queryParams = new URLSearchParams()

  if (filters?.status?.length) {
    queryParams.append("status", filters.status.join(","))
  }
  if (filters?.priority?.length) {
    queryParams.append("priority", filters.priority.join(","))
  }
  if (filters?.assigneeId?.length) {
    queryParams.append("assigneeId", filters.assigneeId.join(","))
  }
  if (filters?.search) {
    queryParams.append("search", filters.search)
  }

  const url = `${API_ENDPOINTS.TASKS.LIST(projectId)}?${queryParams.toString()}`

  const { data, error, isLoading, mutate } = useSWR<Task[]>(projectId ? url : null, fetcher)

  const createTask = async (taskData: Omit<Task, "id" | "createdAt" | "updatedAt" | "creatorId">) => {
    const response = await fetch(API_ENDPOINTS.TASKS.CREATE(projectId), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(taskData),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Failed to create task")
    }

    mutate()
    return response.json()
  }

  const updateTask = async (taskId: string, updates: Partial<Task>) => {
    const response = await fetch(API_ENDPOINTS.TASKS.UPDATE(taskId), {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(updates),
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Failed to update task")
    }

    mutate()
    return response.json()
  }

  return {
    tasks: data || [],
    loading: isLoading,
    error,
    createTask,
    updateTask,
    refresh: mutate,
  }
}

export function useTask(taskId: string) {
  const { data, error, isLoading, mutate } = useSWR<Task>(taskId ? API_ENDPOINTS.TASKS.DETAIL(taskId) : null, fetcher)

  return {
    task: data,
    loading: isLoading,
    error,
    refresh: mutate,
  }
}
