// Application constants for SynergySphere

export const APP_CONFIG = {
  name: "SynergySphere",
  description: "Advanced Team Collaboration Platform",
  version: "1.0.0",
  author: "SynergySphere Team",
} as const

export const ROUTES = {
  HOME: "/",
  LOGIN: "/auth/login",
  REGISTER: "/auth/register",
  DASHBOARD: "/dashboard",
  PROJECTS: "/projects",
  PROJECT_DETAIL: (id: string) => `/projects/${id}`,
  TASKS: "/tasks",
  TASK_DETAIL: (id: string) => `/tasks/${id}`,
  PROFILE: "/profile",
  SETTINGS: "/settings",
} as const

export const TASK_STATUS = {
  TODO: "todo",
  IN_PROGRESS: "in-progress",
  DONE: "done",
} as const

export const TASK_PRIORITY = {
  LOW: "low",
  MEDIUM: "medium",
  HIGH: "high",
  URGENT: "urgent",
} as const

export const PROJECT_ROLES = {
  OWNER: "owner",
  ADMIN: "admin",
  MEMBER: "member",
} as const

export const NOTIFICATION_TYPES = {
  TASK_ASSIGNED: "task_assigned",
  TASK_COMPLETED: "task_completed",
  PROJECT_INVITE: "project_invite",
  COMMENT_MENTION: "comment_mention",
  DEADLINE_REMINDER: "deadline_reminder",
} as const

export const API_ENDPOINTS = {
  AUTH: {
    LOGIN: "/api/auth/login",
    REGISTER: "/api/auth/register",
    LOGOUT: "/api/auth/logout",
    ME: "/api/auth/me",
  },
  PROJECTS: {
    LIST: "/api/projects",
    CREATE: "/api/projects",
    DETAIL: (id: string) => `/api/projects/${id}`,
    UPDATE: (id: string) => `/api/projects/${id}`,
    DELETE: (id: string) => `/api/projects/${id}`,
    MEMBERS: (id: string) => `/api/projects/${id}/members`,
  },
  TASKS: {
    LIST: (projectId: string) => `/api/projects/${projectId}/tasks`,
    CREATE: (projectId: string) => `/api/projects/${projectId}/tasks`,
    DETAIL: (id: string) => `/api/tasks/${id}`,
    UPDATE: (id: string) => `/api/tasks/${id}`,
    DELETE: (id: string) => `/api/tasks/${id}`,
  },
  COMMENTS: {
    LIST: (taskId: string) => `/api/tasks/${taskId}/comments`,
    CREATE: (taskId: string) => `/api/tasks/${taskId}/comments`,
  },
  NOTIFICATIONS: {
    LIST: "/api/notifications",
    MARK_READ: (id: string) => `/api/notifications/${id}/read`,
  },
} as const

export const BREAKPOINTS = {
  SM: 640,
  MD: 768,
  LG: 1024,
  XL: 1280,
  "2XL": 1536,
} as const

export const COLORS = {
  PRIMARY: "hsl(var(--primary))",
  SECONDARY: "hsl(var(--secondary))",
  ACCENT: "hsl(var(--accent))",
  MUTED: "hsl(var(--muted))",
  DESTRUCTIVE: "hsl(var(--destructive))",
} as const

export const ANIMATIONS = {
  DURATION: {
    FAST: 150,
    NORMAL: 300,
    SLOW: 500,
  },
  EASING: {
    DEFAULT: "cubic-bezier(0.4, 0, 0.2, 1)",
    IN: "cubic-bezier(0.4, 0, 1, 1)",
    OUT: "cubic-bezier(0, 0, 0.2, 1)",
  },
} as const
