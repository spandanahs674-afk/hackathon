import { z } from "zod"

// Authentication schemas
export const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
})

export const registerSchema = z
  .object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    email: z.string().email("Please enter a valid email address"),
    password: z.string().min(6, "Password must be at least 6 characters"),
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  })

// Project schemas
export const createProjectSchema = z.object({
  name: z.string().min(1, "Project name is required").max(100, "Project name is too long"),
  description: z.string().max(500, "Description is too long").optional(),
})

export const updateProjectSchema = z.object({
  name: z.string().min(1, "Project name is required").max(100, "Project name is too long").optional(),
  description: z.string().max(500, "Description is too long").optional(),
  status: z.enum(["active", "archived", "completed"]).optional(),
})

// Task schemas
export const createTaskSchema = z.object({
  title: z.string().min(1, "Task title is required").max(200, "Task title is too long"),
  description: z.string().max(1000, "Description is too long").optional(),
  assigneeId: z.string().uuid().optional(),
  priority: z.enum(["low", "medium", "high", "urgent"]),
  dueDate: z.date().optional(),
  tags: z.array(z.string()).optional(),
})

export const updateTaskSchema = z.object({
  title: z.string().min(1, "Task title is required").max(200, "Task title is too long").optional(),
  description: z.string().max(1000, "Description is too long").optional(),
  assigneeId: z.string().uuid().optional(),
  status: z.enum(["todo", "in-progress", "done"]).optional(),
  priority: z.enum(["low", "medium", "high", "urgent"]).optional(),
  dueDate: z.date().optional(),
  tags: z.array(z.string()).optional(),
})

// Comment schemas
export const createCommentSchema = z.object({
  content: z.string().min(1, "Comment cannot be empty").max(1000, "Comment is too long"),
  parentId: z.string().uuid().optional(),
})

// User profile schemas
export const updateProfileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(50, "Name is too long").optional(),
  email: z.string().email("Please enter a valid email address").optional(),
})

// Invite member schema
export const inviteMemberSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  role: z.enum(["admin", "member"]).default("member"),
})

// Search and filter schemas
export const taskFilterSchema = z.object({
  status: z.array(z.enum(["todo", "in-progress", "done"])).optional(),
  priority: z.array(z.enum(["low", "medium", "high", "urgent"])).optional(),
  assigneeId: z.array(z.string().uuid()).optional(),
  search: z.string().optional(),
})

export const projectFilterSchema = z.object({
  status: z.array(z.enum(["active", "archived", "completed"])).optional(),
  search: z.string().optional(),
})

// Type exports
export type LoginInput = z.infer<typeof loginSchema>
export type RegisterInput = z.infer<typeof registerSchema>
export type CreateProjectInput = z.infer<typeof createProjectSchema>
export type UpdateProjectInput = z.infer<typeof updateProjectSchema>
export type CreateTaskInput = z.infer<typeof createTaskSchema>
export type UpdateTaskInput = z.infer<typeof updateTaskSchema>
export type CreateCommentInput = z.infer<typeof createCommentSchema>
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>
export type InviteMemberInput = z.infer<typeof inviteMemberSchema>
export type TaskFilterInput = z.infer<typeof taskFilterSchema>
export type ProjectFilterInput = z.infer<typeof projectFilterSchema>
