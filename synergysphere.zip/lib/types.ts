// Core data types for SynergySphere platform

export interface User {
  id: string
  email: string
  name: string
  avatar?: string
  role: "admin" | "member"
  createdAt: Date
  updatedAt: Date
}

export interface Project {
  id: string
  name: string
  description?: string
  ownerId: string
  members: ProjectMember[]
  createdAt: Date
  updatedAt: Date
  status: "active" | "archived" | "completed"
}

export interface ProjectMember {
  userId: string
  projectId: string
  role: "owner" | "admin" | "member"
  joinedAt: Date
}

export interface Task {
  id: string
  title: string
  description?: string
  projectId: string
  assigneeId?: string
  creatorId: string
  status: "todo" | "in-progress" | "done"
  priority: "low" | "medium" | "high" | "urgent"
  dueDate?: Date
  createdAt: Date
  updatedAt: Date
  tags?: string[]
}

export interface Comment {
  id: string
  content: string
  authorId: string
  taskId?: string
  projectId: string
  parentId?: string // For threaded discussions
  createdAt: Date
  updatedAt: Date
}

export interface Notification {
  id: string
  userId: string
  type: "task_assigned" | "task_completed" | "project_invite" | "comment_mention" | "deadline_reminder"
  title: string
  message: string
  read: boolean
  relatedId?: string // Task ID, Project ID, etc.
  createdAt: Date
}

// API Response types
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

// Form types
export interface LoginForm {
  email: string
  password: string
}

export interface RegisterForm {
  name: string
  email: string
  password: string
  confirmPassword: string
}

export interface CreateProjectForm {
  name: string
  description?: string
}

export interface CreateTaskForm {
  title: string
  description?: string
  assigneeId?: string
  priority: Task["priority"]
  dueDate?: Date
  tags?: string[]
}

// UI State types
export interface TaskFilters {
  status?: Task["status"][]
  priority?: Task["priority"][]
  assigneeId?: string[]
  search?: string
}

export interface ProjectStats {
  totalTasks: number
  completedTasks: number
  overdueTasks: number
  membersCount: number
}
